package time;

public class Time {
    int jour;
    int heure;
    int minute;
    int seconde;

    public Time(int d, int h, int m, int s) {
        this.jour = d;
        this.heure = h;
        this.minute = m;
        this.seconde = s;
    }

    public Time() {
        this.jour = 0;
        this.heure = 0;
        this.minute = 0;
        this.seconde = 0;
    }

    public Time(String s) {
        String[] res = s.split(":");
        this.jour = new Integer(res[0]).intValue();
        this.heure = new Integer(res[1]).intValue();
        this.minute = new Integer(res[2]).intValue();
        this.seconde = new Integer(res[3]).intValue();
    }

    public void set_jour(int j) {
        this.jour = j;
    }

    public int get_jour() {
        return this.jour;
    }

    public void set_heure(int j) {
        this.heure = j;
    }

    public int get_heure() {
        return this.heure;
    }

    public void set_minute(int m) {
        this.minute = m;
    }

    public int get_minute() {
        return this.minute;
    }

    public void set_seconde(int s) {
        this.seconde = s;
    }

    public int get_seconde() {
        return this.seconde;
    }

    public double toHeure() {
        return (this.jour*24)+this.heure+((double)this.minute/60)+((double)this.seconde/3600);
    } 

}