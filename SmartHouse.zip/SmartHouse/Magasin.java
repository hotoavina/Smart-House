package magasin;

import appareil.*;
import maison.Maison;
import java.util.ArrayList;

public class Magasin {
    Appareil[] disponible;
    Appareil[] choisi;

    public Magasin(Appareil[] dispo, Appareil[] choi) {
        this.disponible = dispo;
        this.choisi = choi;
    }

    public Magasin() {
        this.disponible = null;
        this.choisi = null;
    }

    public void set_disponible(Appareil[] d) {
        this.disponible = d;
    }

    public Appareil[] get_disponible() {
        return this.disponible;
    }

    public void set_choisi(Appareil[] d) {
        this.choisi = d;
    }

    public Appareil[] get_choisi() {
        return this.choisi;
    }

    public ArrayList<Panneau> getPanneaux() {
        ArrayList<Panneau> listPanneaux = new ArrayList();

        for(Appareil app : this.disponible) {
            if(app instanceof Panneau) {
                listPanneaux.add((Panneau)app);
            }
        }

        return listPanneaux;
    }

    public ArrayList<Panneau> getPannChoisi() {
        ArrayList<Panneau> listPanneaux = new ArrayList();

        for(Appareil app : this.choisi) {
            if(app instanceof Panneau) {
                listPanneaux.add((Panneau)app);
            }
        }

        return listPanneaux;
    }

    public ArrayList<Batterie> getBatteries() {
        ArrayList<Batterie> listBatteries = new ArrayList();

        for(Appareil app : this.disponible) {
            if(app instanceof Batterie) {
                listBatteries.add((Batterie)app);
            }
        }

        return listBatteries;
    }

    public ArrayList<Batterie> getBattChoisi() {
        ArrayList<Batterie> listBatteries = new ArrayList();

        for(Appareil app : this.choisi) {
            if(app instanceof Batterie) {
                listBatteries.add((Batterie)app);
            }
        }

        return listBatteries;
    }

    public ArrayList<Panneau> getPanneauEqui(Maison home) {
        ArrayList<Panneau> panneaux = new ArrayList();
        ArrayList<Panneau> pandispo = getPanneaux();
        double nrjActu = 0;
        double total = 0;
        Panneau pN = new Panneau();
        panneaux.add(pN);

        for(int i = 0; i < home.totalConsoJpH().length; i++) {
            nrjActu = 0;
            total = home.totalConsoJpH()[i];
            for(Panneau p : panneaux) {
                nrjActu += p.getnrjVarie()[i];
            }
            //System.out.println(i+" "+total+" "+nrjActu);
            if(total > nrjActu) {
                for(int j = 0; j < pandispo.size(); j++) {
                    if((nrjActu + pandispo.get(j).getnrjVarie()[i]) >= total) {
                        //System.out.println(i);
                        panneaux.add(pandispo.get(j));
                        break;
                    } if(j+1 == pandispo.size()){
                        panneaux.add(pandispo.get(pandispo.size()-1));
                        i--;
                    }
                }
            }
        }
        System.out.println();
        return panneaux;
    }

// batterie accumulateur d' energie donc HS tous les heures

    public ArrayList<Batterie> getBatterieEqui(Maison home) {
        ArrayList<Batterie> batteries = new ArrayList();
        ArrayList<Batterie> battdispo = getBatteries();
        ArrayList<Batterie> temp = new ArrayList();
        double nrjActu = 0;
        double total = 0;
        Batterie bT = new Batterie();
        batteries.add(bT);

        for(int i = 0; i < home.totalConsoNpH().length; i++) {
            total = home.totalConsoNpH()[i];
            
            for(Batterie b : temp) {
                nrjActu += b.getPuissance();
            }
            System.out.println("\t"+i+" total: "+total+" nrjActuel: "+nrjActu);
            if(total > nrjActu) {
                for(int j = 0; j < battdispo.size(); j++) {
                    if((nrjActu + battdispo.get(j).getPuissance()) >= total) {
                        System.out.println("\t\t"+ j +" ajout de "+battdispo.get(j).getPuissance());
                        batteries.add(battdispo.get(j));
                        nrjActu = (nrjActu + battdispo.get(j).getPuissance()) - total;
                        System.out.println("\t\t\t reste: "+nrjActu);
                        temp.clear();
                        break;
                    } if(j+1 == battdispo.size()){
                        System.out.println("\t\tajout de "+battdispo.get(j).getPuissance());
                        temp.clear();
                        temp.add(battdispo.get(battdispo.size()-1));
                        batteries.add(battdispo.get(j));
                        i--;
                    }
                }
            } else nrjActu -= total;
        }

        System.out.println();
        return batteries;
    }

    public int minPann(ArrayList<Panneau> liste, int i) {
        double min = liste.get(0).getnrjVarie()[i];
        int indice = 0;
        
        for(int j = 1; j < liste.size(); j++) {
            if(min > liste.get(j).getnrjVarie()[i]) {
                min = liste.get(j).getnrjVarie()[i];
                indice = j;
            }
        }
        return indice;
    }

    public int minBatt(ArrayList<Batterie> liste) {
        double min = liste.get(0).getPuissance();
        int indice = 0;
        
        for(int j = 1; j < liste.size(); j++) {
            if(min > liste.get(j).getPuissance()) {
                min = liste.get(j).getPuissance();
                indice = j;
            }
        }
        return indice;
    }

    public int maxBatt(ArrayList<Batterie> liste) {
        double min = liste.get(0).getPuissance();
        int indice = 0;
        
        for(int j = 1; j < liste.size(); j++) {
            if(min < liste.get(j).getPuissance()) {
                min = liste.get(j).getPuissance();
                indice = j;
            }
        }
        return indice;
    }

    public int maxPann(ArrayList<Panneau> liste, int i) { 
        double min = liste.get(0).getnrjVarie()[i];
        int indice = 0;
        
        for(int j = 1; j < liste.size(); j++) {
            if(min < liste.get(j).getnrjVarie()[i]) {
                min = liste.get(j).getnrjVarie()[i];
                indice = j;
            }
        }
        return indice;
    }

    public ArrayList<Panneau> getPannDef(Maison home) {
        ArrayList<Panneau> lesPanneaux = new ArrayList();
        ArrayList<Panneau> temp = new ArrayList();
        ArrayList<Panneau> temp2 = getPannChoisi();
        double nrjActu = 0;
        double total = 0;

        for(int i = 0;  i<home.totalConsoJpH().length; i++) {
            nrjActu = 0;
            total = home.totalConsoJpH()[i];

            for(Panneau p : temp2) {
                nrjActu += p.getnrjVarie()[i];
            }

            //System.out.println("nrjActus de PannChoisi: "+i+" "+nrjActu+" \tTotal: "+total);

            if(total > nrjActu) {
                ArrayList<Panneau> temp3 = getPanneaux();
                Panneau app = temp3.get(minPann(temp3,i));
                ArrayList<Panneau> temp4 = new ArrayList();
                temp2.add(app);
                //System.out.println("1)Ajout de "+app.getPuissance()+" taille(temp2): "+temp2.size());
                
                for(int j = 0; j<home.totalConsoJpH().length; j++) {
                    nrjActu = 0;
                    total = home.totalConsoJpH()[j];
                    //System.out.println("taille actuelle de temp2: "+temp2.size());

                    for(Panneau p : temp2) {
                        nrjActu += p.getnrjVarie()[j];
                    }

                    //System.out.println("\tnrjActus de PannTemp: "+j+" "+nrjActu+" \tTotal: "+total);

                    if(total <= nrjActu && i==j) {
                        temp.add(app);
                        break;
                    } 

                    if(j+1 == home.totalConsoJpH().length) {
                        temp4.add(temp3.get(minPann(temp3,i)));
                        temp2.remove(temp2.size()-1);
                        //System.out.println("size de temp2 dans ajout: "+temp2.size());
                        temp3.remove(minPann(temp3,i));  //Problem Resolue
                        temp3 = temp3.size() == 0 ? getPanneaux() : temp3;
                        for(int k = 0; k<temp4.size()-1; k++) {
                            if(temp4.get(k).getPuissance() == temp4.get(temp4.size()-1).getPuissance()) {
                                temp2.add(temp4.get(maxPann(temp4,i)));
                                temp.add(temp4.get(maxPann(temp4,i)));
                                break;
                            }
                        }
                        /*System.out.println("liste dans temp4 ");
                        for(Panneau p : temp4) {
                            System.out.println("\t"+p.getPuissance());
                        }*/
                        app = temp3.get(minPann(temp3,i));
                        temp2.add(app);
                        //System.out.println("Ajout de "+app.getPuissance()+"\n");
                        j = -1;
                    }
                }
            }
        }
        return temp;
    }

    public ArrayList<Batterie> getBattExces(Maison home) {
        ArrayList<Batterie> temp = new ArrayList();
        ArrayList<Batterie> temp2 = getBattChoisi();
        double nrjActu = 0;
        double total = 0;
        //int it2 = 1;

        for(Batterie p : temp2) {
                nrjActu += p.getPuissance();
        }

        for(int i = 0;  i<home.totalConsoNpH().length; i++) {
            total = home.totalConsoNpH()[i];

            //System.out.println("nrjActus de BattChoisi: "+i+" "+nrjActu+" \tTotal: "+total);

            nrjActu = nrjActu <= 0 ? 0 : nrjActu - total;
        }
        //System.out.println(nrjActu);
        if(nrjActu > 0){
            ArrayList<Batterie> temp3 = getBatteries();
            int id = temp3.size()-1;
            for(int i = 0; nrjActu > 0; i++) {
                nrjActu -= temp3.get(id).getPuissance();
                temp.add(temp3.get(id));
                //System.out.println("Ajout de "+temp.get(temp.size()-1).getPuissance());
                if(nrjActu <= 0) {
                    nrjActu += temp3.get(id).getPuissance();
                    //System.out.println("Suppression de "+temp.get(temp.size()-1).getPuissance());
                    temp3.remove(id);
                    temp.remove(temp.size()-1);
                    id = temp3.size()-1;

                    if(temp3.size() == 0)
                        break;
                }
            }
        }
        return temp;
    }

    public ArrayList<Batterie> getBattDef(Maison home) {
        ArrayList<Batterie> temp = new ArrayList();
        ArrayList<Batterie> temp2 = getBattChoisi();
        double nrjActu = 0;
        double total = 0;
        //int it2 = 1;

        for(Batterie p : temp2) {
                nrjActu += p.getPuissance();
        }

        for(int i = 0;  i<home.totalConsoNpH().length; i++) {
            total = home.totalConsoNpH()[i];

            System.out.println("nrjActus de BattChoisi: "+i+" "+nrjActu+" \tTotal: "+total);

            double diff = nrjActu;

            if(nrjActu < total) {

                for(int j = 0; j < getBatteries().size(); j++) {

                    System.out.println("\tnrjActus de BattChoisi: "+j+" "+diff+" \tTotal: "+total);

                    if((diff + getBatteries().get(j).getPuissance()) >= total) {
                        temp.add(getBatteries().get(j));
                        nrjActu = (diff + getBatteries().get(j).getPuissance())-total;
                        break;
                    }
                    if(j+1 == getBatteries().size()) {
                        diff += getBatteries().get(maxBatt(getBatteries())).getPuissance();
                        temp.add(getBatteries().get(maxBatt(getBatteries())));
                        j = -1;
                    }
                }
            }
        }
        return temp;
    }

    //a revoire s' il y a des erreurs

    public ArrayList<Panneau> getPannExces(Maison home) {
        ArrayList<Panneau> lesPanneaux = new ArrayList();
        ArrayList<Panneau> temp = new ArrayList();
        ArrayList<Panneau> temp2 = getPannChoisi();
        double nrjActu = 0;
        double total = 0;
        double val = -1;
        Panneau pN = new Panneau();
        lesPanneaux.add(pN);

        for(int i = 0;  i<home.totalConsoJpH().length; i++) {
            nrjActu = 0;
            total = home.totalConsoJpH()[i];

            for(Panneau p : getPannChoisi()) {
                nrjActu += p.getnrjVarie()[i];
            }

            //System.out.println("nrjActus de PannChoisi: "+i+" "+nrjActu+" \tTotal: "+total);
            
            if(total >= nrjActu) {
                System.out.println("Vrai");
                lesPanneaux.clear();
                lesPanneaux = null;
                return lesPanneaux;
            }
        }

        for(int i = 0; i<home.totalConsoJpH().length; i++) {
            nrjActu = 0;
            total = home.totalConsoJpH()[i];

            for(Panneau p : temp2) {
                nrjActu += p.getnrjVarie()[i];
            }

            if(total < nrjActu) {
                temp.add(temp2.get(minPann(temp2,i)));
                //System.out.println(i+"\tMin: "+temp2.get(minPann(temp2,i)).getPuissance());
                temp2.remove(minPann(temp2,i));
                ArrayList<Panneau> temp4 = temp2;
                ArrayList<Panneau> temp3 = new ArrayList();
                int it = 0;

                for(int j = 0;  j<home.totalConsoJpH().length; j++) {
                    nrjActu = 0;
                    total = home.totalConsoJpH()[j];

                    for(Panneau p : temp2) {
                        nrjActu += p.getnrjVarie()[j];
                    }

                    //System.out.println("nrjActus de PannTemp: "+j+" "+nrjActu+" \tTotal: "+total);

                    if(total >= nrjActu) {
                        //System.out.println("Ca ne marche pas");
                        temp2.add(temp.get(temp.size()-1));
                        temp.remove(temp.size()-1);
                        break;
                    }
                    if(j+1 == home.totalConsoJpH().length){
                        temp3.add(temp4.get(minPann(temp4,i)));
                        //System.out.println();
                        temp.add(temp4.get(minPann(temp4,i)));
                        temp2.remove(minPann(temp2,i));
                        temp2.add(temp3.get(it));
                        temp4.remove(minPann(temp4,i));
                        it++;
                        j = -1;
                        
                        /*for(int k = 0; k<temp3.size() -1 ; k++) {
                            if(temp3.get(k).getPuissance() == temp4.get(minPann(temp4,i)).getPuissance())
                                j = home.totalConsoJpH().length;
                        }*/

                        /*for(int k = 0; k<temp2.size(); k++) {
                            System.out.println("\t\tvaleur temp2 - "+k+" "+temp2.get(k).getPuissance());
                        }
                        System.out.println(i+"\tMin: "+temp4.get(minPann(temp4,i)).getPuissance());*/
                    }
                }
            }
        }
        return temp;
    }
}