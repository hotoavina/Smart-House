public class Essaie{
    String id;
    double[] tab;
    String nom;
    String prenom;
    int nbr;
    boolean vf;

    
    public void set_id(String s) {
        this.id = s;
    }

    public String get_id() {
        return this.id;
    }
    
    public void set_nbr(int s) {
        this.nbr = s;
    }

    public int get_nbr() {
        return this.nbr;
    }
    
    public void set_vf(boolean s) {
        this.vf = s;
    }

    public boolean get_vf() {
        return this.vf;
    }

    public void set_tab(double[] d) {
        this.tab = d;
    }

    public double[] get_tab() {
        return this.tab;
    }

    public void set_nom(String n) {
        this.nom = n;
    }

    public String get_nom() {
        return this.nom;
    }

    public void set_prenom(String n) {
        this.prenom = n;
    }

    public String get_prenom() {
        return this.prenom;
    }
}