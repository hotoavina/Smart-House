import magasin.Query;
import appareil.Panneau;
import magasin.Connect;
import appareil.Appareil;
import time.Time;
import appareil.Batterie;
import java.util.ArrayList;
import user.User;
import maison.Maison;
import java.lang.reflect.*;
import static java.lang.System.out;
import java.lang.reflect.*;
import magasin.Magasin;
import fenetre.SmartHouse;
import javax.swing.*;

public class Test4 {
    public static void main(String[] args) {

        Connect con = new Connect("oracle.jdbc.driver.OracleDriver","jdbc:oracle:thin:@localhost:1521:orcl","magasin","mag");

        new Thread( new SmartHouse(con)).start();
        /*Object[] indices = {3,5,1,2,3};
        Object[] tr = {0,0,1,1};
        System.arraycopy(indices, 0, tr, 2, 2);*/
        //SwingUtilities.invokeLater(new SmartHouse());
    }
}