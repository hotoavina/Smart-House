package appareil;

import javax.swing.JLabel;
import time.Time;
import listener.LabelListener;
import java.awt.event.*;

public class Appareil extends JLabel {
    String id;
    String img;
    String nom;
    double tension;
    double intensite;
    double prix;
    Time[][] duree;

    public Appareil(double t, double i, double p) {
        super();
        this.tension = t;
        this.intensite = i;
        this.prix = p;
    }

    public Appareil() {
        super();
        this.tension = 0;
        this.intensite = 0;
        this.prix = 0;
    }

    public void set_id(String i) {
        this.id = i;
    }

    public String get_id() {
        return this.id;
    }

    public void set_img(String i) {
        this.img = i;
    }

    public String get_img() {
        return this.img;
    }

    public void set_nom(String i) {
        this.nom = i;
    }

    public String get_nom() {
        return this.nom;
    }

    public void set_tension(double t){
        this.tension = t;
    }


    public double get_tension(){
        return this.tension;
    }

    public void set_intensite(double t){
        this.intensite = t;
    }

    public double get_intensite(){
        return this.intensite;
    }

    public void set_prix(double t){
        this.prix = t;
    }

    public double get_prix(){
        return this.prix;
    }

    public void set_duree(Time[][] c) {
        this.duree = c;
    }

    public Time[][] get_duree() {
        return this.duree;
    }

    public double getPuissance(){
        return tension*intensite;
    }

    public double[] nrjConsoJN() {
        double[] nrj = new double[2];
        double[] tab = compterHeure();
        double p = getPuissance();
        nrj[0] = tab[0]*p;
        nrj[1] = tab[1]*p;

        return nrj;
    }

    public double[] consoParHeurJ() {
        double[] conso = new double[12];
        int i = 0;
        for(double d : trancherHeur()) {
            conso[i] = d*getPuissance();
            i++;
        }
        return conso;
    } 

    public double[] consoParHeurN() {
        double[] conso = new double[12];
        int i = 0;
        for(double d : trancherHeurN()) {
            conso[i] = d*getPuissance();
            i++;
        }
        return conso;
    }

    public double[] trancherHeur() {
        double[] val = new double[12];
        
        for(int i = 0; i<val.length; i++) {
            val[i] = 0;
        }

        for(int i = 0; i<duree.length; i++) {
            int j = 0;

            if(duree[i][1].get_jour()==duree[i][0].get_jour()){
    
                if(duree[i][0].get_heure()>=6 && duree[i][1].get_heure()<=18) {
                
                    for(j = duree[i][0].get_heure()-6; j<duree[i][1].get_heure()-6; j++) {
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0){
                        int m = duree[i][0].get_heure()==6 ? 0 : duree[i][0].get_heure()-6;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    }
                    if(j!=12)
                        val[j] = duree[i][1].get_minute()!=0?(double)duree[i][1].get_minute()/60:0;
                } else if(duree[i][0].get_heure()<=6 && duree[i][1].get_heure()>=6 && duree[i][1].get_heure()<=18) {
                    for(j = 0; j<duree[i][1].get_heure()-6; j++){
                        val[j] = 1;
                    }
                    if(j != 12)
                        val[j] = duree[i][1].get_minute()!=0?(double)duree[i][1].get_minute()/60:0;
                } else if(duree[i][0].get_heure()>=6 && duree[i][0].get_heure()<18 && duree[i][1].get_heure()>=18) {
                    for(j = duree[i][0].get_heure()-6; j<12; j++){
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0){
                        int m = duree[i][0].get_heure()==6 ? 0 : duree[i][0].get_heure()-6;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    }
                } else if(duree[i][0].get_heure()<=6 && duree[i][0].get_heure()>=0 && duree[i][1].get_heure()>=18 && duree[i][1].get_heure()<=23) {
                    for(j = 0; j<12; j++){
                        val[j] = 1;
                    }
                }
            } else if(duree[i][1].get_jour()!=duree[i][0].get_jour()) {
                if(duree[i][0].get_heure()<6 && duree[i][1].get_heure()>=6 && duree[i][1].get_heure()<=18) {
                    for(j = 0; j<duree[i][1].get_heure()-6; j++){
                        val[j] = 1;
                    }
                    if(j != 12)
                        val[j] = duree[i][1].get_minute()!=0?(double)duree[i][1].get_minute()/60:0;
                }               
            }
        }
        return val;
    }

    public double[] trancherHeurN() {
        double[] val = new double[12];

        for(int i = 0; i<val.length; i++) {
            val[i] = 0;
        }

        for(int i = 0; i<duree.length ; i++) {
            int j = 0;
            if(duree[i][1].get_jour()==duree[i][0].get_jour()) {

                if(duree[i][0].get_heure()>=18 && duree[i][1].get_heure()<=23) {
                    for(j = duree[i][0].get_heure()-18; j<duree[i][1].get_heure()-18; j++) {
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        int m = duree[i][0].get_heure()==18 ? 0 : duree[i][0].get_heure()-18;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    }
                    val[j] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60:0;
                } else if(duree[i][0].get_heure()>=1 && duree[i][1].get_heure()<=6) {
                    for(j = duree[i][0].get_heure()+6; j<duree[i][1].get_heure()+6; j++) {
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        int m = duree[i][0].get_heure()==1 ? 7 : duree[i][0].get_heure()+6;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    }
                    if(j!=12)
                        val[j] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60:0;
                }
                else if(duree[i][0].get_heure()>6 && duree[i][0].get_heure()<18 && duree[i][1].get_heure()>18 && duree[i][1].get_heure()<=23) {
                    for(j = 0; j<duree[i][1].get_heure()-18; j++) {
                        val[j] = 1;
                    }
                    val[j] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60 : 0;
                } else if(duree[i][0].get_heure()>=1 &&  duree[i][1].get_heure()>6 && duree[i][1].get_heure()<18) {
                    for(j = duree[i][0].get_heure()+6; j<12; j++) { //si l' heure change, ça change (12)
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        int m = duree[i][0].get_heure()==1 ? 7 : duree[i][0].get_heure()+6;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    } 
                } else if(duree[i][0].get_heure()>=1 && duree[i][0].get_heure()<=6 && duree[i][1].get_heure()>=18 && duree[i][1].get_heure()<=23) {
                    for(j = duree[i][0].get_heure()+6; j<12; j++) { //si l' heure change, ça change (12)
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        try{
                            int m = duree[i][0].get_heure()==1 ? 7 : (j>12 ? 0 : duree[i][0].get_heure()+6); //toucher
                            val[m] = (60-(double)duree[i][0].get_minute())/60;
                        } catch(ArrayIndexOutOfBoundsException e) {
                            int m = duree[i][0].get_heure()==1 ? 7 : (j>=12 ? 0 : duree[i][0].get_heure()+6); //toucher
                            val[m] = (60-(double)duree[i][0].get_minute())/60;
                        }
                    }
                    for(j = 0; j<duree[i][1].get_heure()-18; j++) {
                        val[j] = 1;
                    }
                    val[j] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60 : 0;
                }
            } else if(duree[i][1].get_jour()!=duree[i][0].get_jour()) {
                if(duree[i][0].get_heure()>=18 && duree[i][1].get_heure()>=0) {
                    for(j = duree[i][0].get_heure()-18; j<5; j++) {
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        int m = duree[i][0].get_heure()==18 ? 0 : duree[i][0].get_heure()-18;
                        val[m] = (60-(double)duree[i][0].get_minute())/60;
                    }
                    for(j = 7; j<duree[i][1].get_heure()+6; j++) {
                        val[j] = 1;
                    }
                    if(j!=12) {
                        int m = j!=7 || duree[i][1].get_heure()==1 ? j : 6;
                        val[m] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60:0; //toucher
                    }
                    
                    val[5] = 1;
                    val[6] = duree[i][1].get_heure()>0 ? 1 : (val[6]!=0 ? val[6] : 0);
                } else if(duree[i][0].get_heure()==0 && duree[i][1].get_heure()>0 && duree[i][1].get_heure()<=6) {
                    for(j = 6; j<duree[i][1].get_heure()+6; j++) {
                        val[j] = 1;
                    }
                    if(duree[i][0].get_minute()!=0) {
                        val[6] = (60-(double)duree[i][0].get_minute())/60;
                    }
                    if(j!=12)
                        val[j] = duree[i][1].get_minute()!=0 ? (double)duree[i][1].get_minute()/60:0;
                }
            }
        }
        return val;
    }

    public double[] compterHeure() {
        double res[] = new double[2];
        res[0] = 0;
        res[1] = 0;
        for(int i = 0; i < duree.length; i++)  {
            double temps1=duree[i][0].toHeure();
            double temps2=duree[i][1].toHeure();
            double difference=temps2-temps1;

            if(duree[i][0].get_jour()==duree[i][1].get_jour()) {
                double val = difference;

                if(duree[i][0].get_heure()>=6 && duree[i][1].get_heure()<=18) {
                    res[0] += val;
                }
                else if(duree[i][0].get_heure()<6 && duree[i][1].get_heure()>=0 && duree[i][1].get_heure()<=6){
                    res[1] += val;
                }
                else if(duree[i][0].get_heure()>=18 && duree[i][1].get_heure()<=23){
                    res[1] += val;
                }
                else if(duree[i][0].get_heure()<6 && duree[i][1].get_heure()>6 && duree[i][1].get_heure()<18){
                    Time t6 = new Time(0,6,0,0);
                    double temp = t6.toHeure()-temps1;
                    res[1] += temp;
                    temp = temps2 - t6.toHeure();
                    res[0] += temp;
                }
                else if(duree[i][0].get_heure()>6 && duree[i][0].get_heure()<18 && duree[i][1].get_heure()>18){
                    Time h6 = new Time(0,18,0,0);
                    double temp = h6.toHeure()-temps1;
                    res[0] += temp;
                    temp = temps2 - h6.toHeure();
                    res[1] += temp;
                }
                else {
                    res[0] += 12;
                    
                    Time t6 = new Time(0,6,0,0);
                    Time t18 = new Time(0,18,0,0);
                    double temp = t6.toHeure()-temps1;
                    res[1] += temp;
                    temp = temps2 - t18.toHeure();
                    res[1] += temp;
                }
            } else {
                if(duree[i][0].get_heure()>18 && duree[i][1].get_heure()<6){
                    res[1] += duree[i][1].toHeure()-duree[i][0].toHeure();
                }
                else if(duree[i][0].get_heure()>18 && duree[i][1].get_heure()>6 && duree[i][1].get_heure()<18){
                    Time t6 = new Time(1,6,0,0);
                    res[1] += t6.toHeure() - duree[i][0].toHeure();
                    res[0] += duree[i][1].toHeure() - t6.toHeure();
                }
                else {/*if(duree[i][0].get_heure()>6 && duree[i][1].toHeure()<18 && duree[i][01].toHeure()>6 && duree[i][1].toHeure()<18){*/
                    Time t18 = new Time(0,18,0,0);
                    Time t6 = new Time(1,6,0,0);
                    res[0] += t18.toHeure() - duree[i][0].toHeure();
                    res[0] += duree[i][1].toHeure() - t6.toHeure();
                    res[1] += 12; 
                }
            }
        }
        return res;
    }
}