package maison;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.ArrayList;
import appareil.*;
import user.User;

public class Maison extends JPanel{
    ArrayList<Appareil> liste;
    JLabel img;
    User proprio;

    public Maison(ArrayList<Appareil> app, User u) {
        super(new GridBagLayout());
        setBorder(new TitledBorder("HOME"));
        this.liste = app;
        this.proprio = u;
    }

    public Maison(String imge) {
        super(new GridBagLayout());
        setBorder(new TitledBorder("HOME"));
        ImageIcon ii = new ImageIcon(imge);
        this.img = new JLabel(ii,JLabel.CENTER);
        add(img);
        this.liste = new ArrayList();
        this.proprio = null;
    }

    public void set_liste(ArrayList<Appareil> l) {
        this.liste = l;
    }

    public ArrayList<Appareil> get_liste() {
        return this.liste;
    }

    public Appareil[] getListeTab() {
        Appareil[] tab = new Appareil[this.liste.size()];
        for(int i = 0 ; i < tab.length; i++)
            tab[i] = liste.get(i);
        
        return tab;
    }

    public void set_user(User u) {
        this.proprio = u;
    }

    public User get_user() {
        return this.proprio;
    }

    public Batterie[] getBatterie() {
        ArrayList<Batterie> listeBatt  = new ArrayList();

        for(int i = 0 ; i < getComponentCount() ;i++) {
            if(getComponent(i) instanceof Batterie)
                listeBatt.add((Batterie)getComponent(i));
        }
        Batterie[] tabBatt = new Batterie[listeBatt.size()];
        for(int  i = 0; i<tabBatt.length; i++)
            tabBatt[i] = listeBatt.get(i);

        return tabBatt;
    }

    public Panneau[] getPanneau() {
        ArrayList<Panneau> listePann  = new ArrayList();

        for(int i = 0 ; i < getComponentCount() ;i++) {
            if(getComponent(i) instanceof Panneau)
                listePann.add((Panneau)getComponent(i));
        }
        Panneau[] tabPann = new Panneau[listePann.size()];
        for(int  i = 0; i<tabPann.length; i++)
            tabPann[i] = listePann.get(i);

        return tabPann;
    }

    public Appareil[] getSource() {
        Panneau[] tabPann = getPanneau();
        Batterie[] tabBatt = getBatterie();
        Appareil[] listeApp = new Appareil[tabPann.length+tabBatt.length];
        int i = 0;

        for(i = 0; i < tabPann.length; i++)
            listeApp[i] = tabPann[i];
        
        for(int j = 0; j < tabBatt.length; j++,i++) 
            listeApp[i] = tabBatt[j];

        return listeApp;            
    }

    public double[] totalConsoJN() {
        double[] res = new double[2];
        res[0] = 0;
        res[1] = 0;
        for(int i = 0; i < liste.size(); i++) {
            res[0] += liste.get(i).nrjConsoJN()[0];
            res[1] += liste.get(i).nrjConsoJN()[1];
        }
        
        return res;
    }

    public double[] totalConsoNpH() {
        double[] res = new double[12];

        for(int i = 0; i<res.length; i++){
            res[i] = 0;
            for(int j = 0; j<liste.size(); j++) {
                res[i] += liste.get(j).consoParHeurN()[i];
            }
        }

        return res;
    }

    public double[] totalConsoJpH() {
        double[] res = new double[12];

        for(int i = 0; i<res.length; i++){
            res[i] = 0;
            for(int j = 0; j<liste.size(); j++) {
                res[i] += liste.get(j).consoParHeurJ()[i];
            }
        }

        return res;
    }

    public JScrollPane getTableConso() {
        String[] header = {"Heure","Consommation"};
        String[] a = new String[0];
        double[] lesConso = new double[24];
        if(liste != null){
            System.arraycopy(totalConsoJpH(),0,lesConso,0,12);
            System.arraycopy(totalConsoNpH(),0,lesConso,12,12);

        } else{
            for(int i = 0 ; i < 24; i++)
                lesConso[i] = 0;
        }

        String[][] data = new String[24][2];
        for(int ii = 0; ii<24; ii++) {
            if(ii>=0 && ii<6) {
                data[ii][0] = (ii)+" - "+(1+ii);
                data[ii][1] = lesConso[ii+18]+" w";
            } else {
                data[ii][0] = (ii)+" - "+(1+ii);
                data[ii][1] = lesConso[ii-6]+" w";
            }
        }
        DefaultTableModel model = new DefaultTableModel(data, header);
        JTable table = new JTable(model);
        try{
            table.setAutoCreateRowSorter(true);
        } catch(Exception continuewithNoSort) {
        }
        JScrollPane tableScroll = new JScrollPane(table);
        Dimension tablePreferred = tableScroll.getPreferredSize();
        tableScroll.setPreferredSize(
            new Dimension(tablePreferred.width, tablePreferred.height/3)
        );
        return tableScroll;
    }
}