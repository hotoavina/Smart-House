// auteur Harena S3 P14

package fenetre;

import listener.*;
import appareil.*;
import maison.Maison;
import java.awt.*;
import java.lang.reflect.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import magasin.*;
import java.util.ArrayList;
import javax.swing.table.*;

public class SmartHouse extends Query implements Runnable {
    //Magasin mag;
    Maison home;
    Connect co;
    JPanel gui;
    Appareil app;
    JLayeredPane layeredPane;
    JPanel dynamicLabels2;
    JPanel dynamicLabels;

    public SmartHouse(Connect con) {
        super(con,false);
        this.co = con;
        layeredPane = new JLayeredPane();
        /*this.mag = new Magasin();
        this.mag.set_disponible(lesSources());*/
        this.dynamicLabels2 = null;
        this.dynamicLabels = null;

    }

    /*public Magasin getMag() {
        return this.mag;
    }*/

    public Maison getHome() {
        return this.home;
    }

    public Appareil getApp() {
        return this.app;
    }

    public JLayeredPane getLayeredPane() {
        return this.layeredPane;
    }

    public JPanel getGui() {
        return this.gui;
    }

    public JPanel getDynamicLabels2() {
        dynamicLabels2 = new JPanel(new GridLayout(0,1,1,1));
        dynamicLabels2.setBorder(
            new TitledBorder("Appareils") );
        for(Appareil p : lesApps()) {
          ImageIcon icon = new ImageIcon(p.get_img());
          p.setIcon(icon);
          p.setHorizontalAlignment(JLabel.CENTER);
          p.setText(p.getPuissance()+"w");
          dynamicLabels2.add(p);
        }

        return this.dynamicLabels2;
    }

    public JPanel getDynamicLabels() {
        dynamicLabels = new JPanel(new BorderLayout(4,4));
        dynamicLabels.setBorder(
        new TitledBorder("Les Sources D' energie") );
        final JPanel labels = new JPanel(new GridLayout(0,1,1,1));
        labels.setBorder(
            new TitledBorder("Panneau") );
        for(Panneau p : lesPanneaux()){
            ImageIcon icon = new ImageIcon(p.get_img());
            p.setIcon(icon);
            p.setHorizontalAlignment(JLabel.CENTER);
            p.setText(p.getPuissance()+"w");
            labels.add(p);
        }
        dynamicLabels.add( labels, BorderLayout.WEST );

        final JPanel batterie = new JPanel(new GridLayout(0,1,1,1));
        batterie.setBorder(
            new TitledBorder("Batterie") );
        for(Batterie p : lesBatteries()){
            ImageIcon icon = new ImageIcon(p.get_img());
            p.setIcon(icon);
            p.setHorizontalAlignment(JLabel.CENTER);
            p.setText(p.get_tension()*p.get_intensite()+"w");
            batterie.add(p);
        }
        dynamicLabels.add( batterie, BorderLayout.EAST );

        return dynamicLabels;
    }
    
    public void run() {
        final JFrame frame = new JFrame("Smart House");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        layeredPane.setPreferredSize(new Dimension(1050,702));
        layeredPane.addMouseListener(new LabelListener(this));
        layeredPane.addMouseMotionListener(new LabelListener(this));

        gui = new JPanel(new BorderLayout(5,5));
        gui.setBorder( new TitledBorder("Smart House") );
        gui.setSize(1050,702);
        gui.setLocation(0,0);

        BouttonListener blnr = new BouttonListener(this);
        JButton addNew3 = new JButton("Autre Appareil");
        addNew3.addActionListener(blnr);
        JButton addNew2 = new JButton("Conseiller");
        addNew2.addActionListener(blnr);
        JButton addNew1 = new JButton("Verifier");
        addNew1.addActionListener(blnr);
        JPanel plafComponents = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 3,3));
        plafComponents.setBorder(
            new TitledBorder("fonctionnatlité du system") );
            plafComponents.add(addNew1);
            plafComponents.add(addNew2);
            plafComponents.add(addNew3);

        final UIManager.LookAndFeelInfo[] plafInfos =
            UIManager.getInstalledLookAndFeels();
        String[] plafNames = new String[plafInfos.length];
        for (int ii=0; ii<plafInfos.length; ii++) {
            plafNames[ii] = plafInfos[ii].getName();
        }

        try{
            UIManager.setLookAndFeel(plafInfos[1].getClassName());
            SwingUtilities.updateComponentTreeUI(frame);
            frame.pack();
            frame.setMinimumSize(frame.getSize());
        } catch( Exception e) {
            System.out.println("Erreur au chargement des UI");
        }

        gui.add(plafComponents, BorderLayout.NORTH);

        gui.add(getDynamicLabels(), BorderLayout.WEST);

        gui.add(getDynamicLabels2(), BorderLayout.EAST);

        home = new Maison("img/photo.jpg");
        JScrollPane tableScroll = home.getTableConso();

        JSplitPane splitPane = new JSplitPane(
            JSplitPane.VERTICAL_SPLIT,
            tableScroll,
            new JScrollPane(home));
        gui.add( splitPane, BorderLayout.CENTER );

        layeredPane.add(gui, JLayeredPane.DEFAULT_LAYER);

        frame.getContentPane().add(layeredPane);

        frame.pack();

        frame.setLocationRelativeTo(null);
        try {
            frame.setLocationByPlatform(true);
            frame.setMinimumSize(frame.getSize());
        } catch(Throwable ignoreAndContinue) {
        }

        frame.setVisible(true);
    }

    public ArrayList<Appareil> lesApps() {
        ArrayList<Appareil> liste = new ArrayList();
        String sql = "(select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,"+
            "case  "+
                "when Types.nom!=\'nom\' then \'null\'"+
            " end duree"+
            " from Appareil join Types on Types.id=Appareil.idType"+
            " where Types.nom=\'Simple\')";
        setAVC(false);
        int[] indices = {0,1,2,3,4,5};
        for(Object o : select(new Appareil(), sql, indices)) {
            Appareil p = (Appareil)o;
            liste.add(p);
        }
        return liste;
    }

    public Panneau[] lesPanneaux() {
        ArrayList<Panneau> liste = new ArrayList();
        String sql = "(select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,variation,"+
            " case  "+
                " when Types.nom!=\'nom\' then \'null\'"+
            " end duree,"+
            " case  "+
                " when Types.nom!=\'nom\' then intensite*tension"+
            " end puissance"+
            " from Appareil join Types on Types.id=Appareil.idType"+
            " join Panneau on Appareil.id=Panneau.idApp where Types.nom=\'Panneau\' order by puissance)";
        int[] indices = {0,1,2,3,4,5,7};
        setAVC(true);
        for(Object o : select(new Panneau(), sql, indices)) {
            Panneau p = (Panneau)o;
            liste.add(p);
        }
        Panneau[] pl = new Panneau[liste.size()];
        for(int i = 0; i<liste.size(); i++)
            pl[i] = liste.get(i);
        return pl;
    }

    public Batterie[] lesBatteries() {
        ArrayList<Batterie> liste = new ArrayList();
        String sql = "(select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,seuil,"+
            " case  "+
                " when Types.nom!=\'nom\' then \'null\'"+
            " end duree,"+
            " case "+
                " when Types.nom!=\'nom\' then intensite*tension"+
            " end puissance"+
            " from Appareil join Types on Types.id=Appareil.idType join Batterie on Batterie.idApp=Appareil.id"+
            " where Types.nom=\'Batterie\' order by puissance)";
        int[] indices = {0,1,2,3,4,5,7};
        setAVC(true);
        for(Object o : select(new Batterie(), sql, indices)) {
            Batterie p = (Batterie)o;
            liste.add(p);
        }
        Batterie[] pl = new Batterie[liste.size()];
        for(int i = 0; i<liste.size(); i++)
            pl[i] = liste.get(i);

        return pl;
    }

    public Appareil[] lesSources() {
        int taille = lesBatteries().length + lesPanneaux().length;
        Appareil[] lst = new Appareil[taille];
        int i = 0;

        for( i = 0; i<lesBatteries().length; i++) 
            lst[i] = lesBatteries()[i];
        int k = 0;
        for(Appareil p : lesPanneaux()) {
            lst[i] = lesPanneaux()[k];
            i++;
            k++;
        }

        return lst;
    }
}