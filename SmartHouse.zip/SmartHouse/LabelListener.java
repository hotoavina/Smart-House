package listener;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import appareil.*;
import fenetre.SmartHouse;
import time.Time;
import form.Form;
import maison.Maison;

public class LabelListener implements MouseListener, MouseMotionListener {
    static Appareil label;
    static Container cont;
    SmartHouse SH;
    static int xAdjustment;
    static int yAdjustment;
    static int compteur;
    static int compteur2;
    static int compteur3;

    public LabelListener(SmartHouse s) {
        this.SH = s;
        //this.cont = null;
        xAdjustment = 0;
        yAdjustment = 0;
        compteur = 0;
        compteur2 = 0;
        compteur3 = 0;
        //System.out.println("instancier");
    }

    public int getCompteur3() {
        return this.compteur3;
    }

    public void setCompteur3(int i) {
        compteur3 = i;
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
        
    }

    public void mousePressed(MouseEvent e) {
        label = null;
        Component c =  SH.getGui().findComponentAt(e.getX(), e.getY());
 
        if (c instanceof JPanel) {
            cont =(JPanel)c;
            c = cont.findComponentAt(e.getX(), e.getY());
            //System.out.println(c == null ? "null" : c.getClass().getSimpleName());
            Appareil p = c instanceof Panneau ? (Panneau)c : (c instanceof Batterie ? (Batterie)c : null); 
            //System.out.println(p == null ? "tsy panneau" : p.getPuissance());
            //System.out.println("JPanel");
            
            if(c == null)
                return;
        }

        label = c instanceof Appareil ? (Appareil)c : null;
        
        if(label == null) return;
        
        Point parentLocation = c.getParent().getLocation();
        Point labelLocation = label.getLocation();
        
        xAdjustment = parentLocation.x - e.getX();
        yAdjustment = c instanceof Batterie || c instanceof Panneau ? labelLocation.y - (e.getY()-90) : labelLocation.y - (e.getY()-90);
        
        label.setLocation(e.getX() + xAdjustment, e.getY() + yAdjustment);
        label.setSize(label.getWidth(), label.getHeight());
        /*Appareil app = label;
        app.setLocation(parentLocation.x,labelLocation.y);
        c.getParent().add(app);
        c.getParent().revalidate();
        c.getParent().repaint();
        //c.getParent().setBackground(Color.GREEN);
        /*SH.getGui().getComponent(0).setBackground(Color.GREEN);
        SH.getGui().getComponent(1).setBackground(Color.RED);*/
        //System.out.println(label.getClass().getName());
        if(label instanceof Batterie || label instanceof Panneau) {
            Container p  = SH.getGui().getComponent(2) instanceof JPanel ? (JPanel)SH.getGui().getComponent(2) : (Container)SH.getGui().getComponent(2);
            System.out.println(p.getClass().getSimpleName());

            System.out.println(c.getParent().getComponents().length);
            
            SH.getGui().remove(compteur == 0 ? 1 : (compteur == 1 ? 3 : (compteur == 4 ? 1 : 2)));

            SH.getGui().add(SH.getDynamicLabels(), BorderLayout.WEST);
            SH.getGui().revalidate();
            SH.getGui().repaint();
            
            compteur2 = compteur == 0 ? 3 : (compteur2 == 3 ? 3 : 1);
            compteur = 1;
            //return; 
        } else {
            SH.getGui().remove(compteur2 == 0 ? 2 : (compteur2 == 2 ? 3 : (compteur2 == 3 ? 1 : 2)));

            SH.getGui().add(SH.getDynamicLabels2(), BorderLayout.EAST);
            SH.getGui().revalidate();
            SH.getGui().repaint();
            
            compteur = compteur2 == 0 ? 4 : (compteur == 4 ? 4 : 2);
            compteur2 = 2;
            System.out.println("-"+label.getClass().getSimpleName());
        }
        System.out.println("comteur: "+compteur);
        SH.getLayeredPane().add(label, JLayeredPane.PALETTE_LAYER);
    }

    public void mouseReleased(MouseEvent e) {
        if(label == null) return;
 
        label.setVisible(false);
        Component c =  SH.getGui().findComponentAt(e.getX(), e.getY());
        if(!(label instanceof Panneau) && !(label instanceof Batterie) && c.getParent() instanceof Maison) {
            Time[][] time = new Form().getTime();
            if(time != null) {
                label.set_duree(time);
                System.out.println(label.get_duree()[0][0].get_heure()+":"+label.get_duree()[0][0].get_minute());
                System.out.println(label.get_duree()[0][1].get_heure()+":"+label.get_duree()[0][1].get_minute());
            } else return;
        }
 
        if (c instanceof JLabel){
            Container parent = c.getParent();
            if(parent instanceof Maison) {
                parent.add( label );
                if(!(label instanceof Panneau) && !(label instanceof Batterie)) {
                    SH.getHome().get_liste().add(label);
                    parent = parent.getParent();
                    parent = parent.getParent().getParent();
            
                    parent.remove(compteur3);
                    System.out.println("check "+parent.getClass().getSimpleName());
                    compteur3 = 2;
                    parent.add(SH.getHome().getTableConso());
                }
            } else return;
        } else return;
        
        xAdjustment = 0;
        yAdjustment = 0;
        cont = null;
        label = null;
        //label.setVisible(true);
        

    }

    public void mouseDragged(MouseEvent me) {
        if (label == null) return;
        label.setLocation(me.getX() + xAdjustment, me.getY() + yAdjustment);
    }

    public void mouseMoved(MouseEvent e) {
        
    }
}