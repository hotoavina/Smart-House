package magasin;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
    Connection con;

    public Connect(String driver,String url,String user, String mdp) {
        try {
            Class.forName(driver);
            this.con = DriverManager.getConnection(url, user,mdp);

        } catch (ClassNotFoundException cnfe) {
            System.out.println("la class est inexistante");
        } catch(SQLException Se) {
            System.out.println("probleme de connection");
        }
    }

    public Connection getCon() {
        return this.con;
    } 
}