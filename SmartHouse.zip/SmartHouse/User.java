package user;

public class User {
    String nom;
    String prenom;
    String profession;

    public User(String n,String p, String prof) {
        this.nom = n;
        this.prenom = p;
        this.profession = prof;
    }

    public void set_nom(String n) {
        this.nom = n;
    }

    public String get_nom() {
        return this.nom;
    }

    public void set_prenom(String p) {
        this.prenom = p;
    }

    public String get_prenom() {
        return this.prenom;
    }

    public void set_profession(String p) {
        this.profession = p;
    }

    public String get_profession() {
        return this.profession;
    }
}