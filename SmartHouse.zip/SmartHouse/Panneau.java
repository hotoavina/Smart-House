package appareil;

import appareil.Appareil;
import time.Time;

public class Panneau extends Appareil {

    double[] variation = new double[12];

    public Panneau(){
        super();
        for(int i = 0 ; i< variation.length; i++) {
            variation[i] = 0;
        }
    }

    public Panneau(int p1, int p2, int p3){
        super(p1,p2,p3);
    }

    public void set_variation(double[] d) {
        this.variation = d; 
    }

    public double[] get_variation() {
        return this.variation; 
    }

    public double[] getnrjVarie() {
        double[] nrj = new double[12];

        for(int i = 0; i<variation.length; i++) {
            nrj[i] = getPuissance()*(variation[i]/100);
        }

        return nrj;
    }

    public void set_duree(Time[][] t) {
        this.duree = t;
        for(int i = 0; i < t.length; i++) {
            if(t[i][0].get_heure()<18 || t[i][0].get_heure()>6 || 
            t[i][1].get_heure()<18 || t[i][1].get_heure()>6 || t[i][1].get_jour()!=t[i][0].get_jour()){
                this.duree = null;
                break;
            }
        }
    }
}