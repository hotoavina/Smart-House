create user magasin identified by mag;
alter user magasin account unlock;
grant dba to magasin;

create table Essaie (
  id varchar(20) primary key,
  tab varchar(100),
  nom varchar(100),
  prenom varchar(100),
  nbr int,
  vf int
);

create table Types (
  id varchar(50) primary key,
  nom varchar(50)
);

create table Appareil(
  id varchar(50) primary key,
  img varchar(50),
  nom varchar(50),
  intensite decimal(10,2) default 0,
  tension decimal(10,2) default 0,
  idType varchar(50) not null,
  prix decimal(10,2) default 0,
  FOREIGN KEY(idType) REFERENCES Types(id),
  CONSTRAINT GG CHECK (prix>=0)
);

create table Batterie (
  idApp varchar(50) not null,
  seuil decimal(10,2),
  CONSTRAINT GG1 UNIQUE(idApp,seuil),
  FOREIGN KEY (idApp) REFERENCES Appareil(id)
);

create table Panneau (
  idApp varchar(50) not null,
  variation varchar(50),
  FOREIGN KEY (idApp) REFERENCES Appareil(id)
);

insert into Types values('type1','Simple');
insert into Types values('type2','Batterie');
insert into Types values('type3','Panneau');

--apres les insertion n' oubliez pas de commiter Mr

insert into Appareil values('App1','img/01.jpg','Batterie',12,300,'type2',1000000);
insert into Appareil values('App2','img/02.jpg','Ordinateur',10,7800,'type1',1045000);
insert into Appareil values('App3','img/03.jpg','Panneau',20,1000,'type3',230000);
insert into Appareil values('App4','img/01.jpg','Batterie',11,4000,'type2',89000);
insert into Appareil values('App5','img/07.jpg','Tablette',54,600,'type1',4500);
insert into Appareil values('App6','img/06.jpg','Console',54,1200,'type1',10000);
insert into Appareil values('App7','img/05.jpg','Radio',78,800,'type1',214000);
insert into Appareil values('App8','img/03.jpg','Panneau',98,300,'type3',456000);
insert into Appareil values('App9','img/03.jpg','Panneau',5,1604,'type3',789000);
insert into Appareil values('App10','img/03.jpg','Panneau',87,1891,'type3',147000);
insert into Appareil values('App11','img/03.jpg','Panneau',25,285,'type3',89000);
insert into Appareil values('App12','img/01.jpg','Batterie',36,1785,'type2',10000);
insert into Appareil values('App13','img/04.jpg','Tele',69,330,'type1',780000);

insert into Batterie values('App1',50);
insert into Batterie values('App4',20);
insert into Batterie values('App12',10);

insert into Panneau values('App3','10,20,30,40,50,100,50,40,30,20,10,10');
insert into Panneau values('App9','10,20,30,40,50,100,50,40,30,20,10,10');
insert into Panneau values('App10','10,20,30,40,50,100,50,40,30,20,10,10');
insert into Panneau values('App11','10,20,30,40,50,100,50,40,30,20,10,10');
insert into Panneau values('App12','10,20,30,40,50,100,50,40,30,20,10,10');

insert into  Essaie values('E1.1','1,2,3,4,5,6','Harena1','Gianno1',12,0);
insert into  Essaie values('E1.2','0,2,3,4,5,6','Harena2','Gianno2',14,1);
insert into  Essaie values('E1.3','0,2,3,4,5,6','Harena3','Gianno3',1,1);
insert into  Essaie values('E1.4','0,2,3,4,5,6','Harena4','Gianno4',12,0);

--requete pour instancier les panneau
select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,variation,
  case
    when Types.nom!='nom' then 'null'
  end duree,
  case 
    when Types.nom!='nom' then intensite*tension
  end puissance
from Appareil join Panneau on Appareil.id=Panneau.idApp 
join Types on Types.id=Appareil.idType where Types.nom='Panneau' order by puissance;

--liste des appareils
select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,
  case  
    when Types.nom!='nom' then 'null'
  end duree
from Appareil join Types on Types.id=Appareil.idType
where Types.nom='Simple'

--liste Batterie
select Appareil.id id,img,Appareil.nom nom,intensite,tension,prix,
  case  
    when Types.nom!='nom' then 'null'
  end duree,
  case  
    when Types.nom!='nom' then intensite*tension*((100-seuil)/100)
  end puissance
from Appareil join Types on Types.id=Appareil.idType join Batterie on Batterie.idApp=Appareil.id
where Types.nom='Batterie' order by puissance

--supprimer les tables
drop table Panneau;
drop table Batterie;
drop table Appareil;

SET FEEDBACK OFF;
SET SERVEROUTPUT ON;

DECLARE
  V_START_DATE  CHAR(17) := '30/03/16 21:00:00';
  V_END_DATE    CHAR(17) := '30/03/17 2:00:00';
  V_DATE_DIFF   VARCHAR2(17);

BEGIN

SELECT
  (TO_NUMBER( SUBSTR(NUMTODSINTERVAL(TO_DATE(V_END_DATE , 'DD/MM/YY HH24:MI:SS') - TO_DATE(V_START_DATE, 'DD/MM/YY HH24:MI:SS'), 'DAY'), 02, 9)) * 24) +
  (TO_NUMBER( SUBSTR(NUMTODSINTERVAL(TO_DATE(V_END_DATE , 'DD/MM/YY HH24:MI:SS') - TO_DATE(V_START_DATE, 'DD/MM/YY HH24:MI:SS'), 'DAY'), 12, 2)))  || 
              SUBSTR(NUMTODSINTERVAL(TO_DATE(V_END_DATE , 'DD/MM/YY HH24:MI:SS') - TO_DATE(V_START_DATE, 'DD/MM/YY HH24:MI:SS'), 'DAY'), 14, 6) AS "HH24:MI:SS"
  INTO V_DATE_DIFF
FROM 
  DUAL;

DBMS_OUTPUT.PUT_LINE(V_DATE_DIFF);
END;