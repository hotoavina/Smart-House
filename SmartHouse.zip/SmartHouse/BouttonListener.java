package listener;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import appareil.*;
import fenetre.SmartHouse;
import magasin.Magasin;
import form.Form;
import time.Time;

public class BouttonListener implements ActionListener {
    SmartHouse SH;
    Magasin mag;
    LabelListener l;

    public BouttonListener(SmartHouse sh) {
        this.SH = sh;
        this.mag = null;
        this.l = new LabelListener(SH);
    }

    public void actionPerformed(ActionEvent e){
        mag = new Magasin(SH.lesSources(),SH.getHome().getSource());

        if(((JButton)e.getSource()).getText() == "Autre Appareil") {
            Appareil app = new Form().getNewApp();
            if(app == null) return;
            System.out.println("intensite " + app.get_intensite());
            System.out.println("tension " + app.get_tension());
            System.out.println("duree1 " + app.get_duree()[0][0].get_heure());
            System.out.println("duree2 " + app.get_duree()[0][1].get_heure());
            SH.getHome().get_liste().add(app);

            SH.getHome().getParent().getParent().getParent().remove(l.getCompteur3());
            l.setCompteur3(2);
            SH.getHome().getParent().getParent().getParent().add(SH.getHome().getTableConso());
            

        } else if(((JButton)e.getSource()).getText() == "Conseiller") {
            System.out.println("graphiquement " + SH.getHome().getComponentCount());
            System.out.println("numeriquement " + SH.getHome().get_liste().size());
            
            ArrayList<Panneau> pannAdvise = mag.getPanneauEqui(SH.getHome());
            ArrayList<Batterie> battAdvise = mag.getBatterieEqui(SH.getHome());
            System.out.println("les panneaux equivalentes\n");
            for(Panneau p : pannAdvise)
                System.out.println(p.getnrjVarie()[0]+" w");
            
            System.out.println("les Batteries equivalentes\n");
            for(Batterie p : battAdvise)
                System.out.println(p.getPuissance()+" w");
            String advise = "Les Sources Equivalentes: \n\tPanneaux: \n";
            int k=0;
            //ArrayList note =  compterOccurence((ArrayList<Appareil>)pannAdvise);
            ArrayList note = new ArrayList();
            for(int i = 0; i < pannAdvise.size(); i++) {
                k = 1;
                note.add(pannAdvise.get(i));
                for(int j = i+1; j < pannAdvise.size(); j++) {
                    if(pannAdvise.get(i).getPuissance() == pannAdvise.get(j).getPuissance()) {
                        k++;
                        pannAdvise.remove(j);
                        j--;
                    }
                }
                note.add(k-1 == 0 ? 1 : k);
            }
            for(int i = 2; i < note.size()-1; i += 2) 
                advise += "\t\t"+((Panneau)note.get(i)).getPuissance()+" watt * "+note.get(i+1)+"\n";

            note.clear();

            advise += "\n\tBatteries: \n";

            for(int i = 0; i < battAdvise.size(); i++) {
                k = 1;
                note.add(battAdvise.get(i));
                for(int j = i+1; j < battAdvise.size(); j++) {
                    if(battAdvise.get(i).getPuissance() == battAdvise.get(j).getPuissance()) {
                        k++;
                        System.out.println("suppression "+battAdvise.get(j).getPuissance());
                        battAdvise.remove(j);
                        j--;
                    }
                }
                note.add(k-1 == 0 ? 1 : k);
            }
            for(int i = 2; i < note.size()-1; i+=2) 
                advise += "\t\t"+((Batterie)note.get(i)).get_intensite()*((Batterie)note.get(i)).get_tension()+" watt * "+note.get(i+1)+"\n";
            advise += "\n\n\n";
            new Form().displayAdvise(advise);
        } else if(((JButton)e.getSource()).getText() == "Verifier") {
            System.out.println("les Sources choisis");
            for(Appareil p : mag.get_choisi())
                System.out.println(p.getPuissance()+"w nom: "+p.get_nom());
            
            ArrayList<Panneau> pan = mag.getPannExces(SH.getHome()) != null ? mag.getPannExces(SH.getHome()) : mag.getPannDef(SH.getHome());
            int cas1 = mag.getPannExces(SH.getHome()) != null ? 1 : 0;
            ArrayList<Batterie> batt = mag.getBattExces(SH.getHome()).size() == 0 ? mag.getBattDef(SH.getHome()) : mag.getBattExces(SH.getHome());
            int cas2 = mag.getBattExces(SH.getHome()).size() == 0 ? 0 : 1;

            System.out.println("Panneau");
            for(Panneau p : pan) {
                System.out.println(p.getPuissance()+"w");
            }

            System.out.println("\nBatterie");
            for(Batterie p : batt) {
                System.out.println(p.getPuissance()+"w");
            }
            String advise = "Panneaux en "+( cas1==0 ? "defauts" : "exces" )+" \n";
            int k=0;
            ArrayList note = new ArrayList();
            for(int i = 0; i < pan.size(); i++) {
                k = 1;
                note.add(pan.get(i));
                for(int j = i+1; j < pan.size(); j++) {
                    if(pan.get(i).getPuissance() == pan.get(j).getPuissance()) {
                        k++;
                        pan.remove(j);
                        j--;
                    }
                }
                note.add(k-1 == 0 ? 1 : k);
            }
            for(int i = 0; i < note.size()-1; i += 2) 
                advise += "\t\t"+((Panneau)note.get(i)).getPuissance()+" watt * "+note.get(i+1)+"\n";

            note.clear();

            advise += "\nBatteries en "+( cas2==0 ? "defaut" : "exces " )+" \n";

            for(int i = 0; i < batt.size(); i++) {
                k = 1;
                note.add(batt.get(i));
                for(int j = i+1; j < batt.size(); j++) {
                    if(batt.get(i).getPuissance() == batt.get(j).getPuissance()) {
                        k++;
                        System.out.println("suppression "+batt.get(j).getPuissance());
                        batt.remove(j);
                        j--;
                    }
                }
                note.add(k-1 == 0 ? 1 : k);
            }
            for(int i = 0; i < note.size()-1; i+=2) 
                advise += "\t\t"+((Batterie)note.get(i)).get_intensite()*((Batterie)note.get(i)).get_tension()+" watt * "+note.get(i+1)+"\n";
            advise += "\n\n\n";
            new Form().displayAdvise(advise);

        }
    }

    /*ArrayList compterOccurence(ArrayList<Appareil> ar) {
        ArrayList note = new ArrayList();

        for(int i = 0; i < ar.size(); i++) {
            int k = 1;
            note.add(ar.get(i));
            for(int j = i+1; j < ar.size(); j++) {
                if(ar.get(i).getPuissance() == ar.get(j).getPuissance()) {
                    k++;
                    ar.remove(j);
                    j--;
                }
            }
            note.add(k-1 == 0 ? 1 : k);
        }
        return note;
    }*/
}