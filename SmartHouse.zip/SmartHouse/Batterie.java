package appareil;

import appareil.Batterie;
import time.Time;

public class Batterie extends Appareil {
    double seuil; 

    public Batterie(){
        super();
    }

    public Batterie(int p1, int p2, int p3){
        super(p1,p2,p3);
    }

    public void set_seuil(double d) {
        this.seuil = d;
    }

    public double get_seuil() {
        return this.seuil;
    }

    public double getPuissance() {
        return super.getPuissance()*((100-seuil)/100);
    }

    public void set_duree(Time[][] t) {
        this.duree = t;
        for(int i = 0; i < t.length; i++) {
            if(t[i][0].get_heure()>18 || t[i][0].get_heure()<6 || 
            t[i][1].get_heure()>18 || t[i][1].get_heure()<6){
                this.duree = null;
                break;
            }
        }
    }
}