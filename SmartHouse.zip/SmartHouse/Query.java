package magasin;

import java.text.SimpleDateFormat;
import java.sql.*;
import java.lang.reflect.*;
import java.util.Date;
import java.util.ArrayList;
import java.util.Vector;

public class Query {
    Connect con;
    Statement stmt;
    ResultSet res;
    boolean avecClassMere;

    public Query(Connect c,boolean avc) {
        this.con = c;
        this.avecClassMere = avc;
        try{
            this.stmt = con.getCon().createStatement();
        } catch (SQLException Se) {
            this.stmt = null;
            System.out.println("Probleme lie a l'instance de Statement");
        }
    }

    public Query(){
        this.con=null;
    }

    public void setAVC(boolean avc){
        this.avecClassMere = avc;
    }

    public void insert(Object[] os,String Ntable) {
        String sql = "delete from "+Ntable+" where "+"id"+Ntable.toLowerCase()+
            "!='"+getValueOfField(os[0])[0].toString()+"' or "+"id"+Ntable.toLowerCase()+
            "='"+getValueOfField(os[0])[0].toString()+"'";
            try{
                res = stmt.executeQuery(sql);
            } catch(SQLException Se){
                System.out.println(Se);
            }
        System.out.println(sql+"\n");
        for(int i = 0; i<os.length; i++) {
            insert(os[i],Ntable,getValueOfField(os[i])[0].toString());
        }
    }

    public void insert(Object o, String Ntable, String pk){
        String sql = "insert into " + Ntable + " values (" + "'" + pk + "'";
        for(int i = 1; i<o.getClass().getDeclaredFields().length; i++) {
            if(o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("int") ||
            o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("double"))
                sql += "," + getValueOfField(o)[i].toString();
            else if(o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("java.util.Date")){
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                sql += ",'"+simpleDateFormat.format((Date)getValueOfField(o)[i])+"'";
            }         
            else
                sql += ",'"+getValueOfField(o)[i].toString() + "'";
        }
        sql += ")";
        System.out.println(sql);
        try{
            res = stmt.executeQuery(sql);
            this.con.getCon().commit();
        } catch (SQLException Se) {
            System.out.println(Se);
        }   
    }


    public void update(Object o, String Ntable, String pk) {
        String sql1 = "select * from " + Ntable;
        String sql = "update " + Ntable + " set "+ "id" + Ntable +"='"+ pk+"'";
        //System.out.println(sql1);
        try{
            res = stmt.executeQuery(sql1);
            for(int i = 1; i< res.getMetaData().getColumnCount(); i++) {
                if(o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("int") ||
                o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("double"))
                    sql += ","+res.getMetaData().getColumnName(i+1).toString() + "=" + getValueOfField(o)[i].toString();
                else if(o.getClass().getDeclaredFields()[i].getType().getName().contentEquals("java.util.Date")){
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    sql += ","+res.getMetaData().getColumnName(i+1).toString() +"='"+simpleDateFormat.format((Date)getValueOfField(o)[i])+"'";
                }         
                else
                    sql += ","+res.getMetaData().getColumnName(i+1).toString() +"='"+getValueOfField(o)[i].toString() + "'";
            }
            sql += " where id" + Ntable + "='"+ pk +"'";
            System.out.println(sql);
            res = stmt.executeQuery(sql);
            this.con.getCon().commit();
            System.out.println(sql);
            
        } catch (SQLException Se) {
            System.out.println(Se);
        }   
    }

    public Object[] select(Object o, String Ntable, int[] ind) {
        ArrayList liste = new ArrayList();
        ArrayList<Field> fields = new ArrayList();
        ArrayList inds = new ArrayList();

        for(int v : ind) {
            inds.add(v);
        }

        // a enlever pour generaliser plus tard
        if(avecClassMere) {
            for(Field f : o.getClass().getSuperclass().getDeclaredFields())
                fields.add(f);
        }

        for(Field f : o.getClass().getDeclaredFields()) 
                fields.add(f);


        String sql = "select " + fields.get(0).getName(); 
        int i = 0;
        for(i = 1; i<fields.size(); i++) {
            sql += "," + fields.get(i).getName();
        }
        sql += " from " + Ntable;
        //System.out.println(sql);
        try{
            res = stmt.executeQuery(sql);
            sql = "";
            while(res.next()){
                for(i = 1; i<=res.getMetaData().getColumnCount(); i++) {
                    if(fields.get(i-1).getType().getName().contentEquals("int") || fields.get(i-1).getType().getName().contentEquals("double")){
                        if(inds.contains(i-1)) {
                            sql += res.getString(i)+"#!#";
                        } else{
                            sql += "0"+"#!#";
                        }
                    } else if(fields.get(i-1).getType().getName().contentEquals("boolean")) {
                        if(inds.contains(i-1)) {
                            sql += res.getString(i)+"#!#";
                        } else{
                            sql += "false"+"#!#";
                        }
                    } else {
                        if(inds.contains(i-1)) {
                            sql += res.getString(i)+"#!#";
                        } else{
                            sql += "null"+"#!#";
                        }
                    }
                }
                //System.out.println(sql);
                liste.add(instancier(o,sql));
                sql = "";
            } 
        } catch(SQLException Se) {
            System.out.println(Se);
        }
        Object[] tableaux = liste.toArray();
        return tableaux;
    }

    public Object[] select(Object o, String Ntable) {
        int[] ind = new int[o.getClass().getDeclaredFields().length];

        for(int i = 0; i < ind.length; i++) {
            ind[i] = i;
        }

        return select(o, Ntable, ind);
    }

    public Object[] getValueOfField(Object o){
        Method[] m = o.getClass().getDeclaredMethods();
        Field[] f = o.getClass().getDeclaredFields();
        Object[] values = new Object[f.length];
        for(int i = 0; i<m.length ; i++){
            for(int j = 0; j<o.getClass().getDeclaredFields().length; j++){
                if (m[i].getName().toLowerCase().contentEquals("get_" + f[j].getName().toLowerCase())){
                    try{
                        values[j] = m[i].invoke(o);
                        
                    }catch(IllegalAccessException e){
                        System.out.println("Access denied");
                    }catch(InvocationTargetException e){
                        System.out.println("Missing Target");
                    }
                }
            }
        }
        return values;
    }

    public Object sum(String Ntable,String column) {
        String sql = "select sum("+column+") from "+Ntable;
        System.out.println(sql);
        try{
            res = stmt.executeQuery(sql);
            while(res.next()){
                return res.getString(1);
            }
        } catch(SQLException Se){
            System.out.println(Se);
        }
        return "null";
    }

    public Object instancier(Object object3,String s){
        Object instance = "";
        try {
            Class classe = Class.forName(object3.getClass().getName());
            instance = classe.newInstance();
            
            ArrayList<Field> fields = new ArrayList();
            if(avecClassMere) {
                for(int i = 0 ; i<instance.getClass().getSuperclass().getDeclaredFields().length ; i++)
                    fields.add(instance.getClass().getSuperclass().getDeclaredFields()[i]);
            }
            for(int i = 0; i<instance.getClass().getDeclaredFields().length; i++)
                fields.add(instance.getClass().getDeclaredFields()[i]);

            String[] valeur = s.split("#!#"); 
            Method m;
            for(int i = 0; i<fields.size(); i++){
                if(fields.get(i).getType().getName().contentEquals("java.lang.String")){
                    try{
                        m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), String.class);
                    } catch(NoSuchMethodException e) {
                        m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), String.class);
                    }
                    if(valeur[i].contentEquals("null"))
                        continue;
                    else
                        m.invoke(instance,valeur[i]);
                }
                else if(fields.get(i).getType().getName().contentEquals("int")){
                    try{
                        m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), int.class);
                    } catch(NoSuchMethodException e){
                        m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), int.class);
                    }
                    m.invoke(instance,new Integer(valeur[i]).intValue());
                }
                else if(fields.get(i).getType().getName().contentEquals("double")){
                    try{
                        m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), double.class);
                    } catch (NoSuchMethodException e) {
                        m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), double.class);
                    }
                    m.invoke(instance,new Double(valeur[i]).doubleValue());
                }
                else if(fields.get(i).getType().getName().contentEquals("boolean")){
                    try {
                        m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), boolean.class);
                    } catch(NoSuchMethodException e) {
                        m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), boolean.class);
                    }
                    String bll = "";
                    if(valeur[i].contentEquals("1") || valeur[i].contentEquals("0")) {
                        bll = valeur[i].contentEquals("1") ? "true" : "false";
                    } else {
                        bll = valeur[i];
                    }
                    m.invoke(instance,new Boolean(bll).booleanValue());
                }
                else if(fields.get(i).getType().getName().contentEquals("java.util.Date")){
                    if(valeur[i].contentEquals("null")){
                        continue;
                    }
                    String[] mini_valeur = valeur[i].split(" ")[0].split("-");
                    try{
                        m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), java.util.Date.class);
                    }catch(NoSuchMethodException e) {
                        m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), java.util.Date.class);
                    }
                    m.invoke(instance,new Date(new Integer(mini_valeur[0]).intValue()-1900,new Integer(mini_valeur[1]).intValue() - 1,new Integer(mini_valeur[2]).intValue()));
                } 
                else if(fields.get(i).getType().isArray()) {
                    if(valeur[i].contentEquals("null")){
                        continue;
                    }
                    if(fields.get(i).getType().getComponentType().getName().contentEquals("double")) {
                        String[] mini_valeur = valeur[i].split(",");
                        double[] table = new double[mini_valeur.length];
                        for(int j = 0; j<mini_valeur.length; j++) {
                            table[j] = new Double(mini_valeur[j]).doubleValue();
                        }
                        try{
                            m = instance.getClass().getDeclaredMethod("set_" + fields.get(i).getName(), double[].class);
                        } catch(NoSuchMethodException e) {
                            m = instance.getClass().getSuperclass().getDeclaredMethod("set_" + fields.get(i).getName(), double[].class);
                        }
                        m.invoke(instance,table);
                    }
                }
            }
        }   catch (ClassNotFoundException cnfe) {
            System.out.println("la class est inexistante");
          } catch (InstantiationException ie) {
            System.out.println("la Class n' est pas instanciable !!!");
          } catch (IllegalAccessException iae) {
            System.out.println("la class n' est pa Accessible");
        } catch(NoSuchMethodException e) {
            System.out.println("la methode n' existe pas ");
         } catch(InvocationTargetException e){
            System.out.println("Missing Target");
        }
        return instance;
    }

}