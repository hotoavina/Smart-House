package form;

import javax.swing.*;
import appareil.*;
import time.*;
import java.lang.reflect.*;

public class Form extends JOptionPane{
    JFrame parent;
    JTextField[] fields;
    Object[] message;
    Time[][] duree;

    public Form() {
        parent = new JFrame();
        fields = null;
        message = null;
        duree = null;
        parent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Appareil getNewApp() {
        this.fields = new JTextField[6];
        for(int i = 0; i < fields.length; i++) {
            fields[i] = new JTextField();
        }
        this.message = new Object[12]; 
    		this.message[0] = "Entrer le nom de l' appareil:";
            this.message[1] = fields[0];
    		this.message[2] = "Entrer le tension (V) de l' appareil:";
            this.message[3] = fields[1];
    		this.message[4] = "Entrer l' intensité de l' appareil:";
            this.message[5] = fields[2];
            this.message[6] = "Entrer le prix de l' appareil:";
            this.message[7] =  fields[3];
            this.message[8] = "Entrer heure début:";
            this.message[9] = fields[4];
            this.message[10] = "Entrer heure fin:";
            this.message[11] = fields[5];
        Appareil app = new Appareil();
        int test = 0;
        int option = JOptionPane.showConfirmDialog(
            this.parent, this.message, "Formulaire pour un nouveau App", JOptionPane.OK_OPTION
        );
        if(option == JOptionPane.OK_OPTION) {
            for(JTextField f : fields){
                if(f.getText().isEmpty()){
                    test = 1;
                    break;
                }
            }
            if(test == 1) 
                getNewApp();

            app.set_nom(this.fields[0].getText());
            try{
                app.set_tension(new Double(this.fields[1].getText()).doubleValue());
                app.set_intensite(new Double(this.fields[2].getText()).doubleValue());
                app.set_prix(new Double(this.fields[3].getText()).doubleValue());
                duree = new Time[1][2];
                duree[0][0] = new Time(this.fields[4].getText());
                duree[0][1] = new Time(this.fields[5].getText());
                app.set_duree(duree);
            } catch(NumberFormatException nfe) {
                return null;
            }
        } else{
            return null;
        }
        return app;
    }

    public Time[][] getTime() {
        this.fields = new JTextField[2];
        for(int j = 0; j < fields.length; j++) 
            fields[j] = new JTextField();

        this.message = new Object[4];
            this.message[0] = "Entrer heure début:";
            this.message[1] = fields[0];
            this.message[2] = "Entrer heure fin:";
            this.message[3] = fields[1];
            int test = 0;
        int option = JOptionPane.showConfirmDialog(
            this.parent, this.message, "Formulaire pour la duree de l' appareil",JOptionPane.OK_OPTION
        );

        if(option == JOptionPane.OK_OPTION) {
            for(JTextField f : fields){
                if(f.getText().isEmpty()){
                    test = 1;
                    break;
                }
            }
            if(test == 1) 
                getTime();

            try{
                duree = new Time[1][2];
                duree[0][0] = new Time(this.fields[0].getText());
                duree[0][1] = new Time(this.fields[1].getText());
            } catch(NumberFormatException nfe) {
                return null;
            }
        } else {
            return null;
        }
        return duree;
    }

    public void displayAdvise(String s) {
        JOptionPane.showMessageDialog(this.parent,s);
    }
}